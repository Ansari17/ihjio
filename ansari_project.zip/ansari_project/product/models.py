from django.db import models

class Product(models.Model):
    title = models.CharField(max_length=64)
    description = models.CharField(max_length=64)
    price = models.IntegerField()
    summary = models.CharField(max_length=64)
    timestamp = models.DateTimeField(auto_now=False, auto_now_add=True, blank=True)
    updated = models.DateTimeField(auto_now=True, auto_now_add=False, blank=True)

    def __str__(self):
        return self.title



# Create your models here.
